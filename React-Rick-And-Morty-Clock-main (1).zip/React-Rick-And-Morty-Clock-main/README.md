<h2 align="center">ساعت ریک اند مورتی | Rick & Morty Alarm Clock</h2>

###

<h4 align="center">دمو | Demo 😁<br><br>https://codingwithenjoy.github.io/React-Rick-And-Morty-Clock</h4>

###

<p align="left"></p>

###

<p align="left"></p>

###

<div align="center">
  <img height="350" src="https://user-images.githubusercontent.com/113675029/226163344-c78c3768-46ad-46b3-8ea0-048ac285c03b.png"  />
</div>

###

<p align="left"></p>

###

<div align="center">
  <img height="350" src="https://user-images.githubusercontent.com/113675029/226163355-967a6cc3-a814-46ae-b423-07b9580238d5.png"  />
</div>

###

<p align="left"></p>

###

<p align="left"></p>

###

<p align="left"></p>

###

<div align="center">
  <a href="https://www.instagram.com/codingwithenjoy/" target="_blank">
    <img src="https://raw.githubusercontent.com/maurodesouza/profile-readme-generator/master/src/assets/icons/social/instagram/default.svg" width="52" height="40" alt="instagram logo"  />
  </a>
  <a href="https://www.youtube.com/@codingwithenjoy" target="_blank">
    <img src="https://raw.githubusercontent.com/maurodesouza/profile-readme-generator/master/src/assets/icons/social/youtube/default.svg" width="52" height="40" alt="youtube logo"  />
  </a>
  <a href="mailto:codingwithenjoy@gmail.com" target="_blank">
    <img src="https://raw.githubusercontent.com/maurodesouza/profile-readme-generator/master/src/assets/icons/social/gmail/default.svg" width="52" height="40" alt="gmail logo"  />
  </a>
  <a href="https://twitter.com/codingwithenjoy" target="_blank">
    <img src="https://raw.githubusercontent.com/maurodesouza/profile-readme-generator/master/src/assets/icons/social/twitter/default.svg" width="52" height="40" alt="twitter logo"  />
  </a>
</div>

###

<p align="left"></p>

###

<h4 align="center">توسعه داده شده توسط برنامه نویسی با لذت</h4>

###
